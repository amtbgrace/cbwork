﻿# -*- coding: utf-8 *-*
'''
功能: CBETA BM-UTF8 (簡單標記版) 轉為 XML-P5-UTF8
設定檔: cbeta.ini
命令列參數:
	bm2p5.py -h 可以看參數說明
需求: Python 3, PythonWin
作者: 周邦信 2009.06.02-2011.8.4
'''
import collections, configparser, datetime, os, re, struct, sys
from optparse import OptionParser
import win32com.client # 要安裝 PythonWin

wits={
'A': '【金藏】',
'B': '【補編】',
'C': '【中華】',
'D': '【國圖】',
'F': '【房山】',
'G': '【佛教】',
'H': '【正史】',
'J':'【嘉興】',
'K': '【麗】',
'L': '【龍】',
'M': '【卍正】',
'N': '【南藏】',
'P': '【北藏】',
'Q': '【磧砂】',
'S': '【宋遺】',
'T':'【大】', 
'U': '【洪武】',
'W': '【藏外】',
'X':'【卍續】', 
}

collectionEng={
'A': 'Jin Edition of the Canon',
'B': 'Supplement to the Dazangjing',
'C': 'Zhonghua Canon - Zhonghua shuju Edition',
'D': 'Selections from the Taipei National Central Library Buddhist Rare Book Collection',
'F': 'Fangshan shijing',
'G': 'Fojiao Canon',
'H': 'Passages concerning Buddhism from the Official Histories',
'I': 'Selections of Buddhist Stone Rubbings from the Northern Dynasties',
'J': 'Jiaxing Canon - Xinwenfeng Edition',
'K': 'Tripiṭaka Koreana - Xinwenfeng Edition',
'L': 'Qianlong Edition of the Canon - Xinwenfeng Edition',
'M': 'Manji Daizōkyō - Xinwenfeng Edition',
'N': 'Southern Yongle Edition of the Canon',
'P': 'Northern Yongle Edition of the Canon',
'Q': 'Qisha Edition of the Canon - Xinwenfeng Edition',
'R': 'Manji Zokuzōkyō - Xinwenfeng Edition',
'S': 'Songzang yizhen - Xinwenfeng Edition',
'T': 'Taishō Tripiṭaka',
'U': 'Southern Hongwu Edition of the Canon',
'W': 'Buddhist Texts not contained in the Tripiṭaka',
'X': 'Manji Shinsan Dainihon Zokuzōkyō',
'Z': 'Manji Dainihon Zokuzōkyō'
}

def out(s):
	global buf
	out1(buf)
	buf = ''
	out1(s)

def out1(s):
	global buf1
	buf1 += s

def out2(s):
	global div_head, buf
	if globals['head_start']: 
		div_head += s
		buf += s
	elif s!='': 
		out(s)

def start_i(tag):
	level = 1
	mo = re.search(r'\d+', tag)
	if mo!=None: level = int(mo.group())
	if not 'item' in opens: opens['item'] = 0
	if not 'list' in opens: opens['list'] = 0
	closeTags('cb:jhead', 'cb:juan', 'p')
	while level<opens['list']:
		out1('</item></list>')
		opens['list'] -= 1
		opens['item'] -= 1
	if  level==opens['list']:
		out1('</item>')
		opens['item'] -= 1
	if level>opens['list']:
		record_open('list')
		out('<list>')
	s = '<item xml:id="item{}p{}{}{:02d}">'.format(vol, old_pb, line_num, char_count)
	out(s)
	opens['item'] += 1
		
def start_p(tag):
	closeTags('p', 'byline', 'head')
	r = get_number(tag)
	out('<p xml:id="p%sp%s%s01"' % (vol, old_pb, line_num))
	if 'r' in head_tag:
		out(' type="pre"')
	if r!='':
		out(' rend="margin-left:%sem"' % r)
	out('>')
	opens['p']=1

def start_inline_p(tag):
	closeTags('p')
	s = '<p xml:id="p%sp%s%s%02d"' % (vol, old_pb, line_num, char_count)
	if char_count>1: s += ' cb:type="inline"'
	mo = re.search(r'<p,(\d+),(\d+)>', tag)
	if mo!=None:
		s += ' rend="margin-left:%sem;text-indent:%sem"' % mo.groups()
	else:
		mo = re.search(r'\d+', tag)
		if mo!=None:
			s += ' rend="margin-left:%sem"' % mo.group()
	s += '>'
	out(s)
	opens['p']=1
	
def start_div(level, type):
	closeTags('p', 'cb:jhead', 'cb:juan')
	close_div(level)
	opens['div'] = level
	if type=='other' and 'W' in head_tag:
		out('<cb:div type="w">')
	else:
		out('<cb:div type="%s">' % type)
	
def start_inline_q(tag):
	global buf, div_head, head_tag, globals
	i=tag.find('m=')
	div_head = ''
	level = 0
	
	mo=re.match('<Q(\d+)', tag)
	level=int(mo.group(1))
	
	start_div(level, 'other')

	mo=re.search('m=(.*?)>', tag)
	if mo is None:
		label = ''
		globals['mulu_start'] = True
	else:
		label=mo.group(1)
		if label != '':
			out('<cb:mulu type="其他" level="%d">%s</cb:mulu>' % (level, label))
		globals['mulu_start'] = False
	globals['head_start'] = True

def close_div(level):
	while opens['div'] >= level:
		out1('</cb:div>')
		opens['div'] -= 1

def start_q(tag):
	global buf, current_div_level, div_head, globals
	
	if '=' in head_tag:
		return
	
	div_head = ''
	level = 0
	
	mo = re.search(r'\d+', tag)
	if mo!=None:
		level = int(mo.group())
		
	globals['mulu_start'] = True
	globals['head_start'] = True
	globals['muluType']='其他'
	start_div(level, 'other')
	buf += '<head>'
	opens['head'] = 1

def choice(tag):
	'''  把 [A>B] 換成 <choice> '''
	mo = re.match(r'\[([^>\]]*?)>(.*?)\]', tag) 
	globals['anchorCount']+=1
	id1='anchor{}'.format(globals['anchorCount'])
	globals['anchorCount']+=1
	id2='anchor{}'.format(globals['anchorCount'])
	s = '<choice cb:from="#{}" cb:to="#{}" cb:resp="#resp1">'.format(id1, id2)
	s += '<corr>{}</corr>'.format(mo.group(2))
	if mo.group(1)=='':
		s += '<sic/>'
	else:
		s += '<sic>{}</sic>'.format(mo.group(1))
	s += '</choice>'
	globals['backApp'] += s + '\n'
	r = '<anchor xml:id="{}" type="cb-app"/>'.format(id1)
	r += mo.group(2)
	r += '<anchor xml:id="{}"/>'.format(id2)
	return r

def myLength(s):
	len = 0
	#s = re.sub(r'\[[^>\]]*?>(.*?)\]', r'\1', s)
	#s = re.sub(r'\[[^>\]]*?\]', '缺', s) # 將組字式取代為單個字
	for c in s:
		if c in '◎。，、；：「」『』（）？！—…《》〈〉．“”　〔〕【】()': continue
		len += 1
	return len

def close_q(tag):
	closeTags('cb:jhead', 'cb:juan', 'p')
	level = int(tag[3:-1])
	close_div(level)
		
def start_inline_T(tag):
	if not 'lg' in opens: opens['lg'] = 0
	if opens['lg']==0:
		closeTags('p')
		out('<lg xml:id="lg%sp%s%s01" type="abnormal">' % (vol, old_pb, line_num))
		opens['lg'] = 1
	closeTags('l')
	r=get_number(tag)
	out('<l rend="text-indent:%sem">' % r)
	record_open('l')
	
def start_inline_o(tag):
	closeTags('p')
	if 'commentary' in opens and opens['commentary']>0:
		out1('</cb:div>')
		opens['div'] -= 1
	start_div(opens['div']+1, 'orig')
	opens['orig'] = 1
	
def start_inline_u(tag):
	closeTags('p')
	if 'orig' in opens and opens['orig']>0:
		out1('</cb:div>')
		opens['div'] -= 1
	start_div(opens['div']+1, 'commentary')
	opens['commentary'] = 1
	
def inline_tag(tag):
	global char_count
	#print(tag, sep=' ', end='')
	if re.match(r'\[([^>\]]*?)>(.*?)\]', tag):
		out(choice(tag))
	elif re.match(r'\[[^>\[ ]+?\]', tag):
		char_count+=1
		out2(gaiji(tag))
	elif tag=='<□>':
		out('<unclear/>')
	elif re.match(r'<I\d+>', tag):
		start_i(tag)
	elif tag=='(':
		out2('<note place="inline">')
	elif tag=='<i>(':
		out2('<note place="interlinear">')
	elif tag==')' or tag==")</i>":
		out2('</note>')
	elif tag =='<j>':
		closeTags('p')
		out('<cb:juan fun="close"><cb:jhead>')
		record_open('cb:juan')
		record_open('cb:jhead')
	#elif tag.startswith('<J'):
	#	start_J(tag)
	elif tag =='</L>':
		closeTags('p')
		while opens['list']>0:
			closeTag('item', 'list')
	elif tag.startswith('<mj'):
		#n=get_number(tag)
		globals['juan_num']+=1
		out('<milestone unit="juan" n="{}"/>'.format(globals['juan_num']))
		out('<cb:mulu type="卷" n="{}"/>'.format(globals['juan_num']))
	elif tag=='<o>':
		start_inline_o(tag)
	elif tag.startswith('<p'):
		start_inline_p(tag)
	elif tag.startswith('<Q'):
		start_inline_q(tag)
	elif tag.startswith('</Q'):
		close_q(tag)
	elif tag.startswith('<T'):
		start_inline_T(tag)
	elif tag=='</T>':
		closeTags('l', 'lg')
	elif tag=='<u>':
		start_inline_u(tag)
	elif tag=='</u>':
		closeTags('p')
		out1('</cb:div>')
		opens['div'] -= 1
	else:
		print(old_pb+line_num+'未處理的標記: ' + tag)

def gaiji(zuzi):
	if zuzi=='[＊]': return zuzi
	if re.match(r'\[\d+\]', zuzi): return zuzi
	rs = win32com.client.Dispatch(r'ADODB.Recordset')
	sql = "SELECT cb, uni, nor_uni FROM gaiji WHERE des='%s'" % zuzi
	rs.Open(sql, conn, 1, 3)
	if rs.RecordCount > 0:
		cb = rs.Fields.Item('cb').Value
		uni = rs.Fields.Item('uni').Value
		nor_uni = rs.Fields.Item('nor_uni').Value
		if not cb in gaijis:
			gaijis[cb]={}
			gaijis[cb]['des'] = zuzi
		if (uni is not None and uni!='') and (nor_uni is None or nor_uni==''):
			return chr(int(uni,16))
		else:
			''' here we add an appropriate PUA character to the g element 
			(strictly speaking, we could then eliminate the g, iff the PUA value is defined in the header) 
			on the other hand, P5 explicitly says, these PUA chars should be removed for exchange. 
			'''
			c=chr(0xF0000+int(cb))
			return '<g ref="#CB{}">{}</g>'.format(cb, c)
	else:
		print('組字式找不到: ' + zuzi)
		return ''

def do_chars(s):
	global buf, char_count, div_head
	print('char_count:', char_count, file=log)
	print('chars:', s, file=log)
	char_count += myLength(s)
	out2(s)

def do_text(s):
	tokens = re.findall(r'(<i>\(|\)</i>|<.*?>|\[[^\]]*?>.*?\]|\[[^>\[ ]+?\]|\(|\)|.)', s)
	for t in tokens:
		if re.match('[<\(\)\[]', t): inline_tag(t)
		else: do_chars(t)
	return s

def closeTag(*tags):
	for t in tags:
		if t in opens:
			out1('</' + t + '>')
			opens[t] -= 1

def closeTags(*tags):
	for t in tags:
		if t in opens:
			while opens[t]>0:
				out1('</' + t + '>')
				opens[t] -= 1

def get_number(s):
	mo=re.search(r'\d+', s)
	if mo==None: return ''
	return mo.group(0)

def record_open(tag):
	if not tag in opens: opens[tag] = 0
	opens[tag] += 1

def start_J(tag):
	n = get_number(tag)
	out('<cb:juan fun="open" n="%s"><mulu type="卷" n="%s"/><cb:jhead>' % (n, n))
	record_open('cb:juan')
	record_open('cb:jhead')

def start_j(tag):
	out('<cb:juan fun="close" n="{}"><cb:jhead>'.format(globals['juan_num']))
	record_open('cb:juan')
	record_open('cb:jhead')

def start_byline(tag):
	if '=' in tag: return
	closeTags('byline', 'cb:jhead', 'cb:juan')
	if 'A' in tag:
		out('<byline cb:type="author">')
	elif 'B' in tag:
		out('<byline cb:type="other">')
	elif 'C' in tag:
		out('<byline cb:type="collector">')
	elif 'E' in tag:
		out('<byline cb:type="editor">')
	opens['byline'] = 1
	
def start_x(tag):
	global buf, div_head, globals
	start_div(1, 'xu')
	buf += '<head>'
	opens['head'] = 1
	globals['mulu_start'] = True
	globals['head_start'] = True
	div_head = ''
	
def do_line_head(tag):
	if 'W' in tag:
		tag = tag.replace('W', '')
		if not globals['inw']:
			globals['inw']=True
			if 'Q' not in tag and 'x' not in tag:
				start_div(1, 'w')
	elif globals['inw']:
		globals['inw']=False
	if ('A' in tag) or ('B' in tag) or ('C' in tag) or ('E' in tag):
		start_byline(tag)
	elif 'I' in tag:
		start_i(tag)
		if 'P' in tag: start_p(tag)
	elif 'J' in tag: start_J(tag)
	elif 'j' in tag: start_j(tag)
	elif 'P' in tag: start_p(tag)
	elif 'Q' in tag: start_q(tag)
	elif 'x' in tag: start_x(tag)
	else: 
		tag = tag.replace('#', '')
		tag = tag.replace('_', '')
		tag = tag.replace('k', '')
		tag = tag.replace('r', '')
		tag = re.sub(r'\d*', '', tag)
		if tag!= '': print(old_pb+line_num+'未處理的標記: ' + tag)
		
def close_sutra(num):
	global buf1, gaijis
	today=datetime.date.today().strftime('%Y/%m/%d')
	out_path = dir_out+'/'+vol+num+'.xml'
	print('out_path:', out_path)
	fo=open(out_path, 'w', encoding='utf8')
	s = """<?xml version="1.0" encoding="utf-8"?>
<TEI xmlns="http://www.tei-c.org/ns/1.0" xmlns:cb="http://www.cbeta.org/ns/1.0" xml:id="%s%s">\n""" % (vol, num)
	n = num[1:]
	s += '''<teiHeader>
	<fileDesc>
		<titleStmt>
			<title>{col}, Electronic version, No. {n} {t}</title>\n'''.format(col=collectionEng[ed], n=n, t=sutras[n]['title'])
	s += '\t\t\t<author>%s</author>\n' % sutras[n]['author']
	s += '''\t\t\t<respStmt><resp>Electronic Version by</resp><name>CBETA</name></respStmt>
		</titleStmt>
		<editionStmt>
			<edition><date>{today}</date></edition>
		</editionStmt>
		<extent>{juan}卷</extent>\n'''.format(today=today, juan=sutras[n]['juan'])
	v = vol[1:]
	v = v.lstrip('0')
	s += '''\t\t<publicationStmt>
			<distributor>
				<name>中華電子佛典協會 (CBETA)</name>
				<address><addrLine>service@cbeta.org</addrLine></address>
			</distributor>
			<availability>
				<p>Available for non-commercial use when distributed with this header intact.</p>
			</availability>
			<date>{today}</date>
		</publicationStmt>
		<sourceDesc>
			<bibl>{col} Vol. {v}, No. {n} </bibl>\n'''.format(today=today, col=collectionEng[ed], v=v, n=n)
	s += '''\t\t</sourceDesc>
	</fileDesc>
	<encodingDesc>
		<projectDesc>
			<p xml:lang="en" cb:type="ly">%s</p>
			<p xml:lang="zh" cb:type="ly">%s</p>
		</projectDesc>\n''' % (sutras[n]['laiyuan_e'], sutras[n]['laiyuan_c'])
	s += '\t\t<charDecl>\n'
	for cb in gaijis:
		s += '\t\t\t<char xml:id="CB%s">\n' % cb
		s += '\t\t\t\t<charName>CBETA CHARACTER CB%s</charName>\n' % cb
		s += '\t\t\t\t<charProp>\n'
		s += '\t\t\t\t\t<localName>composition</localName>\n'
		s += '\t\t\t\t\t<value>%s</value>\n' % gaijis[cb]['des']
		s += '\t\t\t\t</charProp>\n'
		s += '\t\t\t</char>\n'
	s += '\t\t</charDecl>\n'
	s += '\t</encodingDesc>\n'
	s += '''</teiHeader>
<text>
<body>'''
	fo.write(s)
	close_div(1)
	fo.write(buf1)
	buf1 = ''
	fo.write('\n</body>\n')
	fo.write('<back>\n')
	fo.write(' <cb:div type="apparatus">\n')
	fo.write('  <head>校勘記</head>\n')
	fo.write('  <p>\n')
	fo.write(globals['backApp'])
	fo.write('''  </p>
 </cb:div>
</back>
''')
	fo.write('</text></TEI>')
	fo.close()
	gaijis = {}
	
def sutraInit(newSutraNumber):
	if globals['sutraNumber']!='': close_sutra(globals['sutraNumber'])
	globals['anchorCount']=0
	globals['backApp']=''
	globals['head_start'] = False
	globals['inw'] = False
	globals['juan_num'] = 0
	globals['mulu_start'] = False
	globals['sutraNumber'] = newSutraNumber

def convert():
	global buf, char_count, fo, head_tag, line_num, old_pb
	f1=open(BMJingWen, "r", encoding="utf8")
	reo=re.compile(r'\[[^>\[]*?\]') # 組字式
	globals['sutraNumber'] = ''
	for line in f1:
		char_count = 1
		line=line.rstrip()
		aline = line[:len(options.vol)+17]
		text = line[len(options.vol)+17:]
		mo=re.match(r'([A-Z]\d{2,3})(n\d+_)(p\d{4}[a-z])(\d\d)(.+)$', aline)
		(vol, num, pb, line_num, head_tag) = mo.groups()
		print('line_num:', pb+line_num, file=log)
		num=num.rstrip('_')
		if num!=globals['sutraNumber']:
			sutraInit(num)
		pb=pb.lstrip('p')
		if globals['head_start'] and not re.match(r'Q\d?=', head_tag):
			if globals['mulu_start']:
				if div_head != '':
					out1('<cb:mulu type="{}" level="{}">{}</cb:mulu>'.format(globals['muluType'], opens['div'], div_head))
				globals['mulu_start'] = False
			out('')
			closeTags('head')
			globals['head_start']=False
		if pb != old_pb:
			buf += '\n<pb ed="{e}" xml:id="{v}.{n}.{p}" n="{p}"/>'.format(e=ed, v=vol, n=num[1:], p=pb)
			old_pb = pb
			
		buf += '\n<lb'
		if 'k' in head_tag:
			buf += ' type="honorific"'  # 強迫換行
		buf += ' ed="{}" n="{}"/>'.format(ed, pb+line_num)
		
		do_line_head(head_tag)
		do_text(text)
	close_sutra(globals['sutraNumber'])
	f1.close()
	
def read_source():
	global sutras
	fi=open(BMLaiYuan, 'r', encoding='utf8')
	laiyuan={}
	for line in fi:
		line = line.rstrip()
		if line[1:2]==':':
			v=line[0:1]
			l=line[2:].split(',')
			laiyuan[v]=l
		else:
			fields = line.split()
			if len(fields)<5: continue
			if not re.match('[A-Z]', fields[1]): continue
			n = fields[1][1:5]
			print(n)
			sutras[n] = {}
			sutras[n]['title'] = fields[5]
			sutras[n]['juan'] = fields[4]
			s = ' '.join(fields[6:])
			sutras[n]['author'] = s[1:-1]
			c = ''
			e = ''
			for s in fields[0]:
				c += laiyuan[s][0].strip() + '，'
				e += laiyuan[s][1].strip() + ', '
			sutras[n]['laiyuan_c'] = c.rstrip('，')
			sutras[n]['laiyuan_e'] = e.rstrip(', ')
	fi.close()
	
# main
# 讀取 命令列參數
parser = OptionParser()
parser.add_option("-v", dest="vol", help="指定要轉換哪一冊")
parser.add_option("-o", action='store', dest="output", help="輸出資料夾")
(options, args) = parser.parse_args()
vol = options.vol.upper()

# 讀取 設定檔 cbeta.ini
config = configparser.SafeConfigParser()
config.read('cbeta.ini')
gaijiMdb=config.get('default', 'gaijiMdb')
BMLaiYuan=config.get('default', 'BMLaiYuan').format(vol=options.vol)
BMJingWen=config.get('default', 'BMJingWen').format(vol=options.vol)

log=open('bm2p5.log', 'w', encoding='utf8')

# 準備存取 gaiji-m.mdb
conn = win32com.client.Dispatch(r'ADODB.Connection')
DSN = 'PROVIDER=Microsoft.Jet.OLEDB.4.0;DATA SOURCE=%s;' % gaijiMdb
print(DSN)
conn.Open(DSN)

ed = vol[0:1]
dir_in = '../../simple/' + vol
dir_out = os.path.join(options.output, ed, vol)
if not os.path.exists(dir_out): os.makedirs(dir_out)

EditionDate = datetime.date.today();

wit = wits[ed]


debug = True

buf = ''
buf1 = ''
char_count = 1
fo = ''
head_tag = ''
hold = False
div_head = ''
gaijis = {}
line_num = ''
opens = {}
opens['div'] = 0
old_pb = ''
sutras = {}
globals={}

read_source()
convert()